package code;

import javax.swing.JButton;
import javax.swing.ImageIcon;

import java.awt.*;
 
//自定义的按钮构件
public class CustomButton extends JButton{
	private static final long serialVersionUID = 1L;
	
	//按钮所用到的图片
    private ImageIcon img_off;
    private ImageIcon img_on;
    public boolean on = false;

    public CustomButton(String icon_off,String icon_on){
        this.img_off = new ImageIcon(icon_off);
        this.img_on = new ImageIcon(icon_on);
     
        //去边框且透明化
        setBorderPainted(false);
        setContentAreaFilled(false);
        setFocusable(false);
        //鼠标停留时改形状
        //setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        setSize(img_off.getIconWidth(),img_off.getIconHeight());
    }
    
    //表现出按钮点击的效果
    public void paintComponent(Graphics g){
    	
    	if(this.getModel().isPressed()){
    		setSize(img_on.getIconWidth(),img_on.getIconHeight());
    		g.drawImage(img_on.getImage(),1,1,this);
        }
   	    else if(this.getModel().isRollover()) {
   	    	setSize(img_on.getIconWidth(),img_on.getIconHeight());
            g.drawImage(img_on.getImage(),0,0,this);
        }
        else{
        	g.drawImage(img_off.getImage(),0,0,this);
        }
    	super.paintComponent(g); 
    }
    	
}
