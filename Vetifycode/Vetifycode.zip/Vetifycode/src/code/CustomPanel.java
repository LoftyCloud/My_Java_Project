package code;

import java.awt.Graphics;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

//自定义的画板
public class CustomPanel extends JPanel{
	private static final long serialVersionUID = 1L;
    	
    private ImageIcon bg;
    
    public CustomPanel(String bg) {
    	this.setOpaque(false);//设置为透明。
    	try {
        this.bg = new ImageIcon(bg);
    	}catch(Exception e) {
    		//图片丢失则报错
    		e.printStackTrace();
    	}
    }
    
    //用于设置背景图片
    @Override
    public void paintComponent(Graphics g){
        g.drawImage(bg.getImage(),0,0,this.getWidth(),this.getHeight(),this);
        super.paintComponent(g);
    }
}
