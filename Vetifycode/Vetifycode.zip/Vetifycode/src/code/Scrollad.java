package code;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.Timer;

public class Scrollad{
	private static final int rolling_length = 410;// 每滚动一次的刻度
	private int y = 0;// 滚动轴滑动的刻度
	private int index = 0; // 用来计数,算的开始滚动到最后滚动的y
	private int currentResolution = 5; // 动画效果 平滑滚动效果的总耗时
	private int moveMinX;// 每次滚动的开始刻度
	private int moveMaxX;// 每次滚动的结束刻度
	private int max;// 计算滚动面板的滚动轴的最大滑动刻度
	private int count = 0;//记录滚动次数
	
	public JScrollPane js_ad;// 广告滚动条
	private JPanel jp_ad;// 广告画板
	private JButton jb_left,jb_right;//左滑和右滑按钮
	private Timer timer_left = null, timer_right = null;// 两个timer 用于操作两个监听事件 监听左滑和右滑
	private Timer timer = null;//实现滚动条的自动滚动
	//图片
	private ImageIcon imgs_scroll[] = {
            new ImageIcon("picture1.png"),
            new ImageIcon("picture2.png"),
            new ImageIcon("picture3.png"),
            new ImageIcon("picture4.png"),
            new ImageIcon("picture5.png")
    };
	
	public Scrollad() {
		//实例化画板
		jp_ad = new JPanel();
		jp_ad.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));
		for(int i = 0;i < 5;i++){
			jp_ad.add(new JLabel(imgs_scroll[i]));
		}
		jp_ad.setOpaque(false);
		
		
		//实例化滚动条 不要两根滚动条
		js_ad = new JScrollPane(jp_ad, ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER,
				ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		js_ad.setBounds(10, 366, 410, 337);
		js_ad.setBorder(null);
		js_ad.setOpaque(false);
	
		//实例化左滑按钮
		jb_left = new JButton();
		/*
		jb_left = new JButton("<<");
		jb_left.setBorder(null);
		jb_left.setContentAreaFilled(false);
		jb_left.setFocusPainted(false);
		jb_left.setBounds(10, 30, 30, 30);
		*/
		jb_left.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0){
				max = js_ad.getHorizontalScrollBar().getMaximum()
					  - js_ad.getHorizontalScrollBar().getModel().getExtent();// 得到滚动条最大滑动刻度
																			
				moveMinX = (index - 1) * rolling_length > max ? max
						   : (index - 1) * rolling_length;
				moveMaxX = index * rolling_length > max ? max : index
						   * rolling_length;
				if (moveMaxX > 0){
					if (timer_left == null){
						timer_left = new Timer(currentResolution, action_return);
					}
					if (!timer_left.isRunning()){
						timer_left.start();
					}
				}
			}
		});
		
		//实例化右滑按钮
		/*
		jb_right = new JButton(">>");
		jb_right.setBorder(null);
		jb_right.setContentAreaFilled(false);
		jb_right.setFocusPainted(false);
		jb_right.setBounds(80, 30, 30, 30);
		*/
		jb_right = new JButton();
		jb_right.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0){
				max = js_ad.getHorizontalScrollBar().getMaximum()
					  - js_ad.getHorizontalScrollBar().getModel().getExtent();// 得到滚动轴
																				// 最大滑动刻度
				moveMinX = index * rolling_length > 0 ? index
						   * rolling_length : 0;
				moveMaxX = moveMinX + rolling_length > max ? max : moveMinX
						   + rolling_length;
				if (moveMinX < max){
					if (timer_right == null){
						timer_right = new Timer(currentResolution, action_right);
					}
					if (!timer_right.isRunning()){
						timer_right.start();
					}
				}
 
			}
		});
		
		//自动滚动计时器
		timer = new Timer(3500,new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jb_right.doClick();
				count++;
				if(count == 5) {
					count = 0;
					jb_left.doClick();
				}
			}
		});
		timer.start();
	}
	
	//左滑事件
	/*
	private ActionListener action_left = new ActionListener(){
		@Override
		public void actionPerformed(ActionEvent e){
			y -= 10;
			if (y <= moveMinX){
				y = moveMinX;
				timer_left.stop();
				if (index > 0){
					index--;
				}
			}
			js_ad.getHorizontalScrollBar().setValue(y);
		}
	};
	*/
	
	//右滑事件
	private ActionListener action_right = new ActionListener(){
		@Override
		public void actionPerformed(ActionEvent e){
			y += 10;
			if (y >= moveMaxX){
				y = moveMaxX;
				timer_right.stop();
				index++;
			}
			js_ad.getHorizontalScrollBar().setValue(y);
		}
	};
	
	//回到第一张图
	private ActionListener action_return = new ActionListener(){
		@Override
		public void actionPerformed(ActionEvent e){
			y -= 40;
			if (y <= 0){
				y = 0;
				timer_left.stop();
				index = 0;
			}
			js_ad.getHorizontalScrollBar().setValue(y);
		}
	};
	
}
