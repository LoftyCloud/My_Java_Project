package code;

import javax.swing.JButton;
import javax.swing.ImageIcon;

import java.awt.*;

 
//自定义的按钮构件

public class SelectButton extends JButton{
	private static final long serialVersionUID = 1L;
	
	//按钮所用到的图片
    private ImageIcon img;
    public boolean on = false;

    public SelectButton(String icon){
        this.img = new ImageIcon(icon);
 
        //去边框且透明化
        setBorderPainted(false);
        setContentAreaFilled(false);
        setFocusable(false);
        //鼠标停留时改形状
        //setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        setSize(img.getIconWidth(),img.getIconHeight());
    }
    
    //表现出按钮点击的效果
    public void paintComponent(Graphics g){
    	 if(this.getModel().isPressed()){
    		setSize(img.getIconWidth(),img.getIconHeight());
	        g.drawImage(img.getImage(),1,1,this);
	     }
	     else if(this.getModel().isRollover()) {
	    	setSize(img.getIconWidth(),img.getIconHeight());
	        g.drawImage(img.getImage(),0,0,this);
	     }
	     else{
	        g.drawImage(img.getImage(),0,0,this);
	     }
	     super.paintComponent(g); 
    }
}