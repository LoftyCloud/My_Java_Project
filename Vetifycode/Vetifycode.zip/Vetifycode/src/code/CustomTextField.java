package code;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JTextField;


public class CustomTextField extends JTextField{
	private static final long serialVersionUID = 1L;
	
	private Listener key;//键盘监听器
	private int max = 0;
	
	public CustomTextField(int limit) {
		max = limit;
		
		key = new Listener();
		addKeyListener(key);
		
		setFont(new Font("黑体",0,28));
		setForeground(new Color(255, 246, 127));
		setBorder(null);
		setOpaque(false);
		setCaretColor(new Color(255, 246, 127));
		
	}
	
	private class Listener implements KeyListener{
		public void keyTyped(KeyEvent e) {
			String s = getText();
			if(s.length() >= max) 
				e.consume();
		}

		@Override
		public void keyPressed(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void keyReleased(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}
	}
}
