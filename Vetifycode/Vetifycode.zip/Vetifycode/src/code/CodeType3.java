package code;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

public class CodeType3 {
	private static final int bg_width = 442;
	private static final int bg_height = 310;//背景大小
	
	private static int y = 0;//纵坐标
	private int time = 10; // 动画效果
	private Timer timer_open = null, timer_close = null;// 两个timer 用于 操作两个监听事件
	
	public JPanel jp_startbg;
	private JButton jb_close;
	public JButton jb_refresh;
	private JButton[] jb_select;//可供选择的选项
	
	private int rd_theme;//随机主题
	public int rd_number;//随机数量
	public int[] rd_position;//随机位置
	private int[] rd_aim;//随机目标
	
	private String requst;//要求
	private JLabel jl_requst;//目标要求
	
	private JPanel[] jl_selected;//被选中的指示图标
	public int[] judge;//判断是否被选中
	
	private Listener act;//动作监听器
	
	public 	CodeType3() {
		//创建监听器对象
		act = new Listener();
		
		//实例化背景
		jp_startbg = new CustomPanel("startbg.png");
		jp_startbg.setLayout(null);
		jp_startbg.setSize(bg_width, bg_height);
		jp_startbg.setLocation(559, 704);
		
		//验证要求
		jl_requst = new JLabel();
		jl_requst.setFont(new Font("黑体",0,21));
		jl_requst.setForeground(new Color(255,246,127));
		jl_requst.setBounds(92, 1, 200, 55);
		
		//实例化被选中的指示图标
		jl_selected = new CustomLabel[6];
		for(int i = 0;i < 6;i++) {
			jl_selected[i] = new CustomLabel("selected.png",null);
			jl_selected[i].setBounds(10, 8, 39, 39);
		}
		
		getRandom();
		getButton();
		
		//实例化判断是否被选中数组
		judge = new int[6];
		
		//实例化关闭按钮并安装监听器
		jb_close = new CustomButton("close-off.png","close-on.png");
		jb_close.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Close();
			}
		});
		jb_close.setLocation(408, 9);
		jp_startbg.add(jb_close);
		
		//实例化刷新按钮并安装监听器
		jb_refresh = new CustomButton("refresh-off.png","refresh-on.png");
		jb_refresh.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				for(int i = 0;i < 6;i++)
					judge[i] = 0;
				getRandom();
				jp_startbg.removeAll();
				jp_startbg.add(jb_close);
				jp_startbg.add(jb_refresh);
				getButton();
			
			}
		});
		jb_refresh.setLocation(378, 7);
		jp_startbg.add(jb_refresh);
	}
	
	/*
	 * 产生随机数
	 */
	public void getRandom() {
		Random random = new Random();
		rd_theme = random.nextInt(4);//0车 1船 2红绿灯 3斑马线
		rd_number = random.nextInt(4);//0一张 1两张 2三张 3四张
		if(rd_number == 0)
			rd_number = 2;
		rd_position = new int[rd_number+1];
		rd_position = randomCommon(0,5,rd_number+1);
		rd_aim = new int[rd_number+1];
		rd_aim = randomCommon(0,4,rd_number+1);
	}
	
	/*
	 * 随机指定范围内N个不重复的数 
	 * @param min 指定范围最小值 
	 * @param max 指定范围最大值 
	 * @param n 随机数个数 
	 */  
	public static int[] randomCommon(int min, int max, int n){  
	    if (n > (max - min + 1) || max < min) {  
	           return null;  
	       }  
	    int[] result = new int[n];  
	    int count = 0;  
	    while(count < n) {  
	        int num = (int) (Math.random() * (max - min)) + 1;  
	        boolean flag = true;  
	        for (int j = 0; j < n; j++) {  
	            if(num == result[j]){  
	                flag = false;  
	                break;  
	            }  
	        }  
	        if(flag){  
	            result[count] = num;  
	            count++;  
	        }  
	    }  
	    return result;  
	}  
	
	/*
	 * 判断key在数组arr中是否存在
	 * @param arr 数组
	 * @param key 待查找值
	 * @return key在数组arr中是否存在，true：存在，false：不存在
	 */
	public static boolean exist(int[] arr,int key) {
		for(int i = 0;i <arr.length;i++) {
			if(arr[i] == key) {
				return true;
			}
		}
		return false;
	}
	
	//根据随机数生成按钮
	public void getButton() {
		jb_select = new SelectButton[6];
		String dir = "";//路径
		
		//根据随机数确定目标主题
		switch(rd_theme) {
			case 0 :
				dir = "img//车//car";
				requst = "汽  车";
				break;
			case 1 :
				dir = "img//船//boat";
				requst = "船  艇";
				break;
			case 2 :
				dir = "img//灯//lamp";
				requst = "红绿灯";
				break;
			case 3 :
				dir = "img//路//load";
				requst = "斑马线";
				break;
			default :
				break;
		}
		
		//根据随机数先生成目标按钮
		for(int i = 0;i <= rd_number;i++) {
			jb_select[rd_position[i]] = new SelectButton(dir+String.valueOf(rd_aim[i])+".png");
		}
		
		//对其余按钮填充干扰选项
		int[] temp = new int[5-rd_number];
		temp = randomCommon(1,10,5-rd_number);
		int x = 0;
		for(int j = 0;j <= 5;j++) {
			if(!exist(rd_position,j)) {
				jb_select[j] = new SelectButton("img//其他//other"+String.valueOf(temp[x])+".png");
				x++;
			}
		}
		
		//对按键进行布局
		jb_select[0].setLocation(6, 60);
		jp_startbg.add(jb_select[0]);
		jb_select[1].setLocation(151, 60);
		jp_startbg.add(jb_select[1]);
		jb_select[2].setLocation(296, 60);
		jp_startbg.add(jb_select[2]);
		jb_select[3].setLocation(6, 186);
		jp_startbg.add(jb_select[3]);
		jb_select[4].setLocation(151, 186);
		jp_startbg.add(jb_select[4]);
		jb_select[5].setLocation(296, 186);
		jp_startbg.add(jb_select[5]);
		
		//安装监听器
		for(int i = 0;i < 6;i++) {
			jb_select[i].addActionListener(act);
		}
		
		//设置要求
		jl_requst.setText(requst);
		jp_startbg.add(jl_requst);
	}
	
	//打开和关闭的移动效果
	public void Open() {
		if(timer_open == null)
			timer_open = new Timer(time,action_show);
		if (!timer_open.isRunning())
			timer_open.start();
	}
	
	private ActionListener action_show = new ActionListener()
	{
		@Override
		public void actionPerformed(ActionEvent e)
		{
			y -= 25;
			if (y <= -bg_height-195)
			{
				y = -bg_height-195;
				timer_open.stop();
			}
			jp_startbg.setLocation(559, 764+y);
		}
	};
	
	public void Close() {
		if(timer_close == null)
			timer_close = new Timer(time,action_close);
		if (!timer_close.isRunning())
			timer_close.start();
	}
	
	private ActionListener action_close = new ActionListener()
	{
		@Override
		public void actionPerformed(ActionEvent e)
		{
			y += 25;
			if (y >= 0)
			{
				y = 0;
				timer_close.stop();
			}
			jp_startbg.setLocation(559, 764+y);
		}
	};
	
	private class Listener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == jb_select[0]) {
				if(judge[0] == 0)
					judge[0] = 1;
				else
					judge[0] = 0;
				
				if(judge[0] == 1)
					jb_select[0].add(jl_selected[0]);
				else
					jb_select[0].remove(jl_selected[0]);
			}
			else if(e.getSource() == jb_select[1]) {
				if(judge[1] == 0)
					judge[1] = 1;
				else
					judge[1] = 0;
				
				if(judge[1] == 1)
					jb_select[1].add(jl_selected[1]);
				else
					jb_select[1].remove(jl_selected[1]);
			}
			else if(e.getSource() == jb_select[2]) {
				if(judge[2] == 0)
					judge[2] = 1;
				else
					judge[2] = 0;
				
				if(judge[2] == 1)
					jb_select[2].add(jl_selected[2]);
				else
					jb_select[2].remove(jl_selected[2]);
			}
			else if(e.getSource() == jb_select[3]) {
				if(judge[3] == 0)
					judge[3] = 1;
				else
					judge[3] = 0;
				
				if(judge[3] == 1)
					jb_select[3].add(jl_selected[3]);
				else
					jb_select[3].remove(jl_selected[3]);
			}
			else if(e.getSource() == jb_select[4]) {
				if(judge[4] == 0)
					judge[4] = 1;
				else
					judge[4] = 0;
				
				if(judge[4] == 1)
					jb_select[4].add(jl_selected[4]);
				else
					jb_select[4].remove(jl_selected[4]);
			}
			else if(e.getSource() == jb_select[5]) {
				if(judge[5] == 0)
					judge[5] = 1;
				else
					judge[5] = 0;
				
				if(judge[5] == 1)
					jb_select[5].add(jl_selected[5]);
				else
					jb_select[5].remove(jl_selected[5]);
			}
		}
	}
}
