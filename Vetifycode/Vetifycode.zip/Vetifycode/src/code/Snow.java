package code;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.JPanel;
 
public class Snow extends JPanel implements Runnable{//画布
	private static final long serialVersionUID = -2986761287590314088L;
	
	final static int Width = 1133;
	final static int Height = 704;
	public boolean exit = false;
	
	public static ArrayList<flake>list=new ArrayList<flake>();
	private BufferedImage img;
	
	public Snow(){
		try {
			img=ImageIO.read(new File("snow.png"));//加载雪花图片
		} catch (IOException e) {
			e.printStackTrace();
		}
		this.setOpaque(false);//设为透明的
		this.setBounds(0, 0, 1133, 704);
		new Thread(this).start();//启动线程
	}
	@Override
		public void paint(Graphics g) {
			// TODO 自动生成的方法存根
			super.paint(g);
			for(int i=0;i<list.size();i++){
				flake x=list.get(i);
				g.drawImage(img, (int)x.x, (int)x.y, x.w, x.h, null);
			}
		}
 
	@Override
	public void run() {
		// TODO 自动生成的方法存根
		int fps=120;//每秒帧数
		int time=1000/fps;
		int ii=0;
		while(!exit){
			long a=System.currentTimeMillis();
			if(ii>3){
				new flake();
				ii=0;
			}
			ii++;
			for(int i=0;i<list.size();i++){//调用所有雪花的run方法
				list.get(i).run();
			}
			repaint();//画雪
			long b=System.currentTimeMillis();
			long c=b-a;
			if(time-c>0)
				try {
					Thread.sleep(time-c);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
		}
	}
	
}
 
class flake{//雪
	public int w,h;
	public float x,y,sdx,sdy;
	
	public flake(){
		w=h=(int)(Math.random()*20+10);//随机大小
		sdx=(float) (Math.random()*0.7+0.3);//x轴移动速度
		sdy=(float) (Math.random()*0.4+0.3);//y轴移动速度
		
		//雪花出现的位置只能在屏幕的上右方
		double gailv=(double)(Snow.Width+Snow.Height)/Snow.Width-1;
		if(Math.random()<gailv){//雪花在屏幕上方
			y=-h;
			x=(int)(Math.random()*Snow.Width);
		}
		else{//雪花在屏幕右方
			x=Snow.Width;
			y=(int)(Math.random()*Snow.Height);
		}
		Snow.list.add(this);//添加进集合
	}
	
	public void run(){//雪花的移动
		//如果雪花超出屏幕范围的话就从集合中删掉
		if(x+w<0||y>Snow.Height||x+w<0||y>Snow.Height){
			Snow.list.remove(this);
		}
		y+=sdy;
		x-=sdx;
	}
}
