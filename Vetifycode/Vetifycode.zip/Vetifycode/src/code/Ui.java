package code;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.io.File;
import java.io.IOException;
import java.net.UnknownHostException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/*
 * 主界面
 */

public class Ui {
	static int mouse_x;
	static int mouse_y;
	
	private int type = 1;//记录目前的验证方式
	
	JFrame jf_logonpage;//登录界面
	JButton jb_sign,jb_option,jb_about,jb_home,jb_exit,jb_indist;//界面按钮
	JButton jb_up,jb_down;//验证方式切换按钮
	JPanel jp_background;//界面背景
	JButton jb_scrolllogo;//左下角滚动栏所用到的按钮
	Scrollad scrollad;//滚动窗
	JTextField jt_account,jt_password,jt_code;//账号、密码、验证码输入框
	//JPanel类的JLabel
	JPanel jl_logo1,jl_logo2,jl_logo3;//两个logo图片
	JPanel jl_sign;//指示图片
	public static String code1,code2;//验证码
	JLabel jl_code;//验证码图片
	JButton jb_type1,jb_type2,jb_type3;//验证方式跳转按钮
	JButton jb_getcode;//第二种验证方式用的获取按钮
	JButton jb_start;//第三种验证方式用的开始按钮
	CodeType3 codetype3;//第三种验证方式
	JLabel jl_getcode;//显示第二种方式获取的验证码
	JPanel jl_line;//分割线
	JLabel jl_judge;//判断验证码对错后的输出结果
	Client client;//客户端程序
	
	Snow snow;//重写的JPanel类 下雪效果
	Listener act;//动作监听器
	
	//获取屏幕尺寸   比例系数0.175
	Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	private final int screenWidth = screenSize.width;
	private final int screenHeight = screenSize.height;
	
	public Ui() {
		//创建监听器对象
		act = new Listener();
		
		//启动客户端
		client = new Client();
		
		//实例化背景画板
	    jp_background = new CustomPanel("background.png");
		jp_background.setLayout(null);
		
		//第三种验证方式
		codetype3 = new CodeType3();
		jp_background.add(codetype3.jp_startbg);
		
		//滚动框logo
		jb_scrolllogo = new CustomButton("scrolllogo.png","scrolllogo.png");
        jb_scrolllogo.setBounds(2, 354, 124, 26);
        jb_scrolllogo.addActionListener(act);
        jp_background.add(jb_scrolllogo);
		
		//添加滚动广告框
        scrollad = new Scrollad();
		jp_background.add(scrollad.js_ad);
		
		//实例化四个按钮
		jb_option = new CustomButton("option-off.png","option-on.png");
		jb_option.setLocation(725, 22);
		jb_option.addActionListener(act);
		jp_background.add(jb_option);//设置
		
		jb_about = new CustomButton("about-off.png","about-on.png");
		jb_about.setLocation(838, 22);
		jb_about.addActionListener(act);
		jp_background.add(jb_about);//关于
		
		jb_home = new CustomButton("home-off.png","home-on.png");  
		jb_home.setLocation(950, 22);
		jb_home.setEnabled(false);
		jb_home.setIcon(new ImageIcon("home-on.png"));
		jp_background.add(jb_home);//返回主页
		
		jb_sign = new CustomButton("sign-off.png","sign-on.png");
		jb_sign.setLocation(702, 615);
		jb_sign.addActionListener(act);
		jp_background.add(jb_sign);//登入
		
		jb_indist = new CustomButton("indist-off.png","indist-on.png");
		jb_indist.setLocation(844, 560);
		jb_indist.addActionListener(act);
		jp_background.add(jb_indist);//第一种方式，看不清验证码，刷新
		
	    jb_getcode = new CustomButton("getcode-off.png","getcode-on.png");
		jb_getcode.setLocation(254,210);
		jb_getcode.addActionListener(act);//第二种方式，获取验证码
		
		jb_start = new CustomButton("start-off.png","start-on.png");
		jb_start.setLocation(231,220);
		jb_start.addActionListener(act);//第三种方式，开始验证
		
		jb_exit = new CustomButton("exit-off.png","exit-on.png");  
		jb_exit.setLocation(1050, 22);
		jb_exit.addActionListener(act);
		jp_background.add(jb_exit);//结束阅读
		
		jb_up = new CustomButton("up-off.png","up-on.png");
		jb_up.setLocation(1025, 498);
		jb_up.addActionListener(act);
		jb_up.setEnabled(false);
		jb_up.setIcon(new ImageIcon("up-on.png"));
		jp_background.add(jb_up);//上一种验证方式
		
		jb_down = new CustomButton("down-off.png","down-on.png");
		jb_down.setLocation(1080, 498);
		jb_down.addActionListener(act);
		jp_background.add(jb_down);//上一种验证方式
		
		//实例化输入框
		jt_account = new CustomTextField(25);
		jt_account.setBounds(576, 304, 400, 50);
		jp_background.add(jt_account);//账号
		
		jt_password = new JPasswordField(1);
		jt_password.setBounds(576, 412, 400, 50);
		jt_password.setFont(new Font("",0,28));
		jt_password.setForeground(new Color(255, 246, 127));
		jt_password.setBorder(null);
		jt_password.setOpaque(false);
		jt_password.setCaretColor(Color.white);
		jt_password.addKeyListener(new KeyListener() {
			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub
				String s = jt_password.getText();
				if(s.length() >= 12) 
					e.consume();
			}
			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				
			}
			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub		
			}		
		});
		jp_background.add(jt_password);//密码
		
		jt_code = new CustomTextField(6);
		jt_code.setBounds(576, 509, 200, 50);
		jp_background.add(jt_code);//验证码
		
		//实例化logo
		jl_logo1 = new CustomLabel("logo1-off.png","logo1-on.png");
		jl_logo1.setBounds(27, 28, 200, 71);
		jp_background.add(jl_logo1);
		
		jl_logo2 = new CustomLabel("logo2-off.png","logo2-on.png");
		jl_logo2.setBounds(46, 167, 329, 128);
		jp_background.add(jl_logo2);
		
		jl_logo3 = new CustomLabel("logo3-off.png","logo3-on.png");
		jl_logo3.setBounds(594, 124, 331, 91);
		jp_background.add(jl_logo3);
		
		jl_sign = new CustomLabel("sign.png",null);
		jl_sign.setBounds(576, 274, 402, 282);
		jp_background.add(jl_sign);
		
		//实例化验证方式指示图标
		jb_type1 = new CustomButton("type1-off.png","type1-off.png");
		jb_type1.setBounds(936, 176, 40, 42);
		jb_type1.setIcon(new ImageIcon("type1-on.png"));
		jp_background.add(jb_type1);
		
		jb_type2 = new CustomButton("type2-off.png","type2-off.png");
		jb_type2.setBounds(986, 176, 45, 42);
		jp_background.add(jb_type2);
		
		jb_type3 = new CustomButton("type3-off.png","type3-off.png");
		jb_type3.setBounds(1041, 176, 43, 44);
		jp_background.add(jb_type3);
		
		//第一种方式，获取验证码
		code1 = VerifyCodeUtils.createOneCodeImage();
		jl_code = new JLabel();
		ImageIcon codeimage = null;
		try {
			codeimage = new ImageIcon(ImageIO.read(new File("code.png")));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		jl_code.setIcon(codeimage);
		jl_code.setBounds(827, 491, 140, 55);
		jp_background.add(jl_code);
		
		jl_judge = new JLabel();
		jl_judge.setFont(new Font("黑体",0,21));
		jl_judge.setForeground(new Color(255,246,127));
		jl_judge.setBounds(574, 562, 300, 55);
		jp_background.add(jl_judge);
		
		//实例化第二种方式获取的验证码
		jl_getcode =new JLabel();
		jl_getcode.setFont(new Font("黑体",1,28));
		jl_getcode.setForeground(new Color(255,246,127));
		jl_getcode.setBounds(270, 232, 300, 55);
		//jl_sign.add(jl_getcode);
		
		//实例化分割线
		jl_line = new CustomLabel("line.png",null);
		jl_line.setBounds(495, 146, 3, 492);
		jp_background.add(jl_line);
				
		//实例化窗口
		jf_logonpage = new JFrame();
		jf_logonpage.setBounds((int)(0.1*screenWidth), (int)(0.02*screenHeight),1133, 704);//窗口大小
		
		//下雪的粒子效果
		snow = new Snow();
		jf_logonpage.add(snow);
				
		jf_logonpage.add(jp_background);
		jf_logonpage.setUndecorated(true);//去掉窗口边框
		jf_logonpage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf_logonpage.setVisible(true);
		//使得窗口可拖动
		jf_logonpage.addMouseListener(new MouseAdapter(){ 
			public void mousePressed(MouseEvent e){
				mouse_x = e.getPoint().x;
				mouse_y = e.getPoint().y;
			}
		});
		jf_logonpage.addMouseMotionListener(new MouseMotionAdapter(){
			public void mouseDragged(MouseEvent e){
				jf_logonpage.setLocation(e.getXOnScreen()-mouse_x, e.getYOnScreen()-mouse_y);
			}
		});
	}
	
	private class Listener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			//对登录按钮
			if(e.getSource() == jb_sign) {
				if(type == 1 || type == 2) {
					String code;
					if(type == 1)
						code = code1;
					else
						code = code2;
					String incode = jt_code.getText().toUpperCase();
					if(incode.equals(code)) {
						jl_judge.setText("成功登入账号！");
					}
					else {
						jt_password.setText("");
						jt_code.setText("");
						jl_judge.setText("验证码输入错误，请重新输入！");
						code1 = VerifyCodeUtils.createOneCodeImage();
						ImageIcon codeimage = null;
						try {
							codeimage = new ImageIcon(ImageIO.read(new File("code.png")));
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						jl_code.setIcon(codeimage);
					}
				}
				else if(type == 3) {
					boolean flag = true;
					int n = 0;//记录选择的图片数量
					
					for(int j = 0;j < 6;j++) {
						if(codetype3.judge[j] == 1)
							n++;
					}
					if(n != codetype3.rd_number+1)
						flag = false;
					
					if(flag) {
						for(int i = 0;i <= codetype3.rd_number;i++) {
							if(codetype3.judge[codetype3.rd_position[i]] != 1) {
								flag = false;
								break;
							}
						}
					}
					
					if(flag) {
						jl_judge.setText("成功登入账号！");
						codetype3.jb_refresh.doClick();
						codetype3.Close();
					}
					else {
						jt_password.setText("");
						jl_judge.setText("选择错误，请重新验证！");
						codetype3.jb_refresh.doClick();
					}
				}
			}
			//对设置按钮
			else if(e.getSource() == jb_option) {		
			}
			//对关于按钮
			else if(e.getSource() == jb_about) {
			}
			//对看不清按钮
			else if(e.getSource() == jb_indist) {
				code1 = VerifyCodeUtils.createOneCodeImage();
				ImageIcon codeimage = null;
				try {
					codeimage = new ImageIcon(ImageIO.read(new File("code.png")));
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				jl_code.setIcon(codeimage);
				jt_code.setText("");
				jl_judge.setText("");//消除提示
			}
			//对第二种验证方式的获取验证码按钮
			else if(e.getSource() == jb_getcode) {
				try {
					client.creatClient();
					jl_getcode.setText(client.s_code);
					jl_getcode.repaint();
					code2 = client.s_code;
				} catch (UnknownHostException e1) {
					// TODO Auto-generated catch block	
				} catch (IOException e1) {
					// TODO Auto-generated catch block
				}
			}
			//第三种方式，开始验证
			else if(e.getSource() == jb_start) {
				jl_judge.setText("");
				codetype3.Open();
			}
			//对上一种验证方式按钮
			else if(e.getSource() == jb_up) {
				if(type == 3) {
					jb_down.setEnabled(true);
					jb_down.setIcon(null);
				}
				type--;
				if(type == 1) {
					jb_up.setEnabled(false);
					jb_up.setIcon(new ImageIcon("up-on.png"));
					
					jb_type2.setIcon(new ImageIcon("type2-off.png"));
					jb_type1.setIcon(new ImageIcon("type1-on.png"));
					
					jt_code.setText("");
					jl_judge.setText("");
					
					jl_sign.remove(jb_getcode);
					jl_sign.remove(jl_getcode);
					
					jp_background.add(jl_code);
					jp_background.add(jb_indist);
				}
				else if(type == 2) {
					jb_type3.setIcon(new ImageIcon("type3-off.png"));
					jb_type2.setIcon(new ImageIcon("type2-on.png"));
					
					jt_code.setText("");
					jt_code.setEditable(true);
					jl_judge.setText("");
					
					jl_sign.remove(jb_start);
					
					jl_sign.add(jb_getcode);
					jl_sign.add(jl_getcode);
				}
			}
			//对下一种验证方式按钮
			else if(e.getSource() == jb_down) {
				if(type == 1) {
					jb_up.setEnabled(true);
					jb_up.setIcon(null);
				}
				type++;
				if(type == 3) {
					jb_down.setEnabled(false);
					jb_down.setIcon(new ImageIcon("down-on.png"));
					
					jb_type2.setIcon(new ImageIcon("type2-off.png"));
					jb_type3.setIcon(new ImageIcon("type3-on.png"));
					
					jt_code.setText("请点击开始验证");
					jt_code.setEditable(false);
					jl_judge.setText("");
					
					jl_sign.remove(jb_getcode);
					jl_sign.remove(jl_getcode);
					
					jl_sign.add(jb_start);
				}
				else if(type == 2) {
					jb_type1.setIcon(new ImageIcon("type1-off.png"));
					jb_type2.setIcon(new ImageIcon("type2-on.png"));
					
					jt_code.setText("");
					jl_judge.setText("");
					
					jp_background.remove(jl_code);
					jp_background.remove(jb_indist);
					
					jl_sign.add(jb_getcode);
					jl_sign.add(jl_getcode);
				}
			}
			//对滚动窗logo反应
			else if(e.getSource() == jb_scrolllogo) {
				jp_background.remove(scrollad.js_ad);
				jp_background.remove(jb_scrolllogo);
			}
			//对结束阅读反应
			else {
				System.exit(0);
			}
		}
	}
	
	public static void main(String args[]) {
		new Ui();
	}
}
