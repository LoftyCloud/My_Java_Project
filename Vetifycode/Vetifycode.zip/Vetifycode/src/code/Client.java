package code;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
//import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {
	BufferedReader input;
	PrintStream output;
	Socket socket;
	public String s_code;
	File verify ;

	public Client() {
		// TODO Auto-generated constructor stub
	}

	public void creatClient() throws UnknownHostException, IOException {
		// TODO Auto-generated method stub
		//InetAddress addr = InetAddress.getLocalHost();
		//socket = new Socket(addr,9000);
		socket = new Socket("192.168.1.102",9000);

		input = new BufferedReader(new InputStreamReader(socket.getInputStream())); 
		output= new PrintStream(socket.getOutputStream()); 
		
		s_code = input.readLine();
	
		verify = new File("output.txt"); 
		if(!verify.exists()) {
			verify.createNewFile();
		}
		
		BufferedWriter fileout = new BufferedWriter(new FileWriter(verify));
		fileout.write(s_code);
		fileout.close();
	}

}
