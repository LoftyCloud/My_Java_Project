package code;

import java.awt.*;
import java.awt.event.*;
 
import javax.swing.*;

public class CustomLabel extends JPanel {
	private static final long serialVersionUID = 1L;
	
    private ImageIcon img_off;// 要变换的图片1
    private ImageIcon img_on;// 要变换的图片2
    
    private boolean isEntered = false; // 鼠标是否在组件里
    private boolean isFirstCreated = true;// 是否是首次绘制的
    
    private boolean ischange = true;
 
    public CustomLabel(String icon_off, String icon_on) {
        img_off = new ImageIcon(icon_off);
        if(icon_on == null)
        	ischange = false;
        else
        img_on = new ImageIcon(icon_on);
        addListener();
        setLayout(null);
        setOpaque(false); // 把panel的背景色设为透明
    }
 
    
    public void paintComponent(Graphics g) {
        int x = 0, y = 0;
        if (isFirstCreated) {
            g.drawImage(img_off.getImage(), x, y, this);
            isFirstCreated = false;
        } else if (isEntered && ischange) {
            g.drawImage(img_on.getImage(), x, y, this);
        } else {
            g.drawImage(img_off.getImage(), x, y, this);
        }
    }
 
    public void addListener() {
        this.addMouseListener(new MouseAdapter() {
            public void mouseExited(MouseEvent e) {
                isEntered = false;
                repaint();
            }
 
            public void mouseEntered(MouseEvent e) {
                isEntered = true;
                repaint();
            }
        });
    }
}
